#!/bin/bash

#export PATH=/Users/fibe/fun/raspi/extrepos/qemu/dist/bin:/Users/fibe/fun/raspi/devel/gcc-arm-none-eabi-4_9-2015q2/bin:$PATH


export PATH=/usr/local/Cellar/qemu/3.0.0/bin:/Users/bkg2018/opt/gcc-arm-none-eabi-7-2018-q2-update/bin:$PATH