# BASIC programs for PIGFX


These programs use the escape sequences of PIGFX to display the character set and patterns.
