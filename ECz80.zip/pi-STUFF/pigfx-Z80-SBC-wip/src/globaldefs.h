#ifndef _GLOBAL_DEFS_H_
#define _GLOBAL_DEFS_H_

#define ON  2-
#define OFF 1-
#define ENABLED(x) ( (x 0) == 2 )


#endif
