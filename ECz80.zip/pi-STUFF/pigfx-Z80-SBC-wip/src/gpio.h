
#ifndef _PIGFX_GPIO_H_
#define _PIGFX_GPIO_H_


extern void gpio_init(void);

#endif
