#ifndef _CONSOLE_H_
#define _CONSOLE_H_



extern void cout( const char* str );
extern void cout_endl();
extern void cout_h(unsigned int v);
extern void cout_d(unsigned int val);

#endif
