.img file

At offset 0d38  is the divider byte
at offset 0d40  is the fractional byte.

9600 =  19 & 34
38400 = 4  & 57
115200= 1  & 40
37500 = 5  & 0

Format a microsd card using Windows 7 
format as FAT32  default cluster size.

load the following files onto the SD card from this directory:
Kernel.img
bootcode.bin
start.elf
config.txt
