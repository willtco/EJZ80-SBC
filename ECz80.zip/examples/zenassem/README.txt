The ZEN assembler was originally written to run on machines such as the Sharp MZ80/700 etc.
It should be possible (though also a challenge) to alter it to work on any Z80 machine,
INcluded here but NOT as a working example, Can't remember how far I got with it!
Have a play!
