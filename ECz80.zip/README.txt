Please read  any/all documents in the DOCS file before Assembling/Running this Z80 system.


DOCS - directory contains whatever helpful documentation has been assembled.
EPROM  - zdevstudio Files (Note if you use these you will need change path definitions in the project file.
pi-stuff  - Pi files (freeware) downloaded + special mods to enable the z80 to use some graphics functions.
TEST_BASIC - contains a version of basic (derived from TINY) - butchered to demonstrate the Z80 calling pi functions
PALS 	- overview and logic equations for the GALs.
KIKAID  - Schematic diagram
EXAMPLES - some useful examples.


NOTE!   It is advisable to install proper jumper type links on the PCB especially for the ROM segment select bits.
Segment 0  (All jumpers made - Rom code for use with raspberry pi  'A' or Zero Pi types.
Segment 1  Jumper  pins  1&2(Open)   3&4(closed)  5&6(closed)    7&8(Closed if using 27512 eprom)  7&8 Don't care if using 27256 eprom
Segements 2-7 [32k],  or 2-15 [64k] blank containing 'ffh'


For tech help - email will-i-was@virginmedia.com

